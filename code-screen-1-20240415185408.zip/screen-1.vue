<template>
  <div
  data-v-6cbd617a=""
  class="nuc-container"
  ncbgtype="bgColor"
  id="d6b8c493-183b-4240-9319-6b1beca60484"
  style="position: relative; z-index: 1; width: 1280px; height: 5000px;"
>
  <h1
    data-v-fa233a80=""
    cite=""
    dir=""
    href=""
    title=""
    class="heading-content"
    theme="theme--light01"
    nctypography="custom"
    id="ebff115d-e642-4105-b1ff-1498d28b7307"
    data-v-6cbd617a=""
    style="position: absolute; top: 65px; left: 585px; color: rgb(4, 123, 242); width: 178px; filter: none; height: 50px; z-index: 2; font-style: normal; margin: 0px; text-align: center; background: transparent; font-family: Roboto; font-weight: 400; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-fa233a80="" style="background: transparent;">
      F‎ormBuilder‎
    </span>
  </h1>
  <h1
    data-v-fa233a80=""
    cite=""
    dir=""
    href=""
    title=""
    class="heading-content"
    theme="theme--light01"
    nctypography="custom"
    id="0eb187c0-001f-4dec-bece-917b012b2488"
    data-v-6cbd617a=""
    style="position: absolute; top: 103px; left: 301px; color: rgb(0, 0, 0); width: 775px; filter: none; height: 246px; z-index: 3; font-style: normal; margin: 0px; text-align: center; background: transparent; font-family: Roboto; font-weight: 700; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-fa233a80="" style="background: transparent;">
      Sales &amp; Marketing Teams Create, Connect, and Share in Minutes!
    </span>
  </h1>
  <button
    data-v-42c4e43a=""
    tabindex="0"
    title=""
    type="button"
    class="btn bootstrap-button btn-primary btn-md"
    theme="theme--light01"
    ncbgtype="bgColor"
    nctypography="custom"
    verticalwidth="60px"
    nucaldatamodel="[object Object]"
    verticalheight="60px"
    horizontalwidth="72.4479px"
    nucalscalewidth=""
    horizontalheight="37.5347px"
    nucalscaleheight=""
    id="42fac894-c7ac-48b2-905d-94508d1eac6c"
    data-v-6cbd617a=""
    style='background: rgb(0, 123, 255); color: rgb(255, 255, 255); border-color: rgb(0, 123, 255); position: absolute; top: 434px; left: 615px; width: 129px; filter: none; height: 54px; z-index: 4; font-style: normal; text-align: center; font-family: "Open Sans"; font-weight: 700; line-height: 1.4; text-indent: 0px; visibility: visible; white-space: normal; border-style: solid; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; border-width: 1px; text-decoration: none; border-radius: 4px;'
  >
    Try For Free‎
  </button>
  <div
    data-v-53feabfc=""
    title=""
    class="main-content"
    theme="theme--light01"
    nctypography="custom"
    nucaldatamodel="[object Object]"
    id="2e5e1032-3857-4ccf-a2f0-48b77ce04abd"
    data-v-6cbd617a=""
    style="position: absolute; top: 359px; left: 405px; color: rgb(0, 0, 0); width: 562px; filter: none; height: 90px; z-index: 5; font-size: 16px; font-style: normal; margin: 0px; text-align: center; background: transparent; font-family: Roboto; font-weight: 400; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-53feabfc="" style="background: transparent;">
      FormBuilder is designed to collect, survey, report, take payments, and
      sync real-time user intelligence to over 6,000 apps.
    </span>
  </div>
  <img
    data-v-3f587a3a=""
    title="Please write a text to display in tooltip..."
    src="https://assets-global.website-files.com/65a921a3cf743bfaa970a60b/65d3d38d944bb9146db1063d_FormBot_Editor.svg"
    class="image"
    dataloading="static"
    nucaldatamodel="[object Object]"
    datamodelfordynamictype="string"
    id="56f5ca59-b533-42b7-aa04-a75d32bef08d"
    data-v-6cbd617a=""
    style="object-fit: fill; position: absolute; top: 522px; left: 294px; width: 752px; filter: none; height: 436px; z-index: 6; margin: 0px; padding: 0px; visibility: visible; border-color: rgb(75, 116, 255); border-style: solid; mix-blend-mode: normal; backdrop-filter: none; border-width: 0px; border-radius: 0px; white-space: normal;"
  />
  <h1
    data-v-fa233a80=""
    cite=""
    dir=""
    href=""
    title=""
    class="heading-content"
    theme="theme--light01"
    nctypography="custom"
    id="919788a3-e1da-40db-b7c1-ec016ff1fe45"
    data-v-6cbd617a=""
    style="position: absolute; top: 1752px; left: 232px; color: rgb(0, 0, 0); width: 390px; filter: none; height: 114px; z-index: 7; font-style: normal; margin: 0px; text-align: left; background: transparent; font-family: Roboto; font-weight: 700; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-fa233a80="" style="background: transparent;">
      Simplify data collection‎
    </span>
  </h1>
  <img
    data-v-3f587a3a=""
    title="Please write a text to display in tooltip..."
    src="https://assets-global.website-files.com/65a921a3cf743bfaa970a60b/65ddea0d0815de19cdb08fa4_Boosting%20Completion%20Rates-p-1080.webp"
    class="image"
    dataloading="static"
    nucaldatamodel="[object Object]"
    datamodelfordynamictype="string"
    id="19aaa53c-0109-44d9-b4e2-cdaef68682ba"
    data-v-6cbd617a=""
    style="object-fit: fill; position: absolute; top: 1157px; left: 701px; width: 475px; filter: none; height: 239px; z-index: 8; margin: 0px; padding: 0px; visibility: visible; border-color: rgb(75, 116, 255); border-style: solid; mix-blend-mode: normal; backdrop-filter: none; border-width: 0px; border-radius: 0px; white-space: normal;"
  />
  <h1
    data-v-fa233a80=""
    cite=""
    dir=""
    href=""
    title=""
    class="heading-content"
    theme="theme--light01"
    nctypography="custom"
    id="8bdeab22-4d42-4f41-a1f2-9bf41806b725"
    data-v-6cbd617a=""
    style="position: absolute; top: 1181px; left: 232px; color: rgb(0, 0, 0); width: 521px; filter: none; height: 114px; z-index: 9; font-style: normal; margin: 0px; text-align: left; background: transparent; font-family: Roboto; font-weight: 700; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-fa233a80="" style="background: transparent;">
      50+ Customizable Elements
    </span>
  </h1>
  <img
    data-v-3f587a3a=""
    title="Please write a text to display in tooltip..."
    src="https://assets-global.website-files.com/65a921a3cf743bfaa970a60b/65ddea0d0815de19cdb08fa4_Boosting%20Completion%20Rates-p-1080.webp"
    class="image"
    dataloading="static"
    nucaldatamodel="[object Object]"
    datamodelfordynamictype="string"
    id="1f271b3a-7c99-499d-a404-f53c510a3eb1"
    data-v-6cbd617a=""
    style="object-fit: fill; position: absolute; top: 2303px; left: 676px; width: 500px; filter: none; height: 250px; z-index: 10; margin: 0px; padding: 0px; visibility: visible; border-color: rgb(75, 116, 255); border-style: solid; mix-blend-mode: normal; backdrop-filter: none; border-width: 0px; border-radius: 0px; white-space: normal;"
  />
  <h1
    data-v-fa233a80=""
    cite=""
    dir=""
    href=""
    title=""
    class="heading-content"
    theme="theme--light01"
    nctypography="custom"
    id="a9d1d461-438c-4a72-a112-6aec697215b4"
    data-v-6cbd617a=""
    style="position: absolute; top: 2311px; left: 232px; color: rgb(0, 0, 0); width: 297px; filter: none; height: 114px; z-index: 11; font-style: normal; margin: 0px; text-align: left; background: transparent; font-family: Roboto; font-weight: 700; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-fa233a80="" style="background: transparent;">
      Customization and branding
    </span>
  </h1>
  <img
    data-v-3f587a3a=""
    title="Please write a text to display in tooltip..."
    src="https://assets-global.website-files.com/65a921a3cf743bfaa970a60b/65ddea0d0815de19cdb08fa4_Boosting%20Completion%20Rates-p-1080.webp"
    class="image"
    dataloading="static"
    nucaldatamodel="[object Object]"
    datamodelfordynamictype="string"
    id="cfb1ef02-51a5-48d4-88c5-3c871bf73ef4"
    data-v-6cbd617a=""
    style="object-fit: fill; position: absolute; top: 1726px; left: 684px; width: 500px; filter: none; height: 250px; z-index: 12; margin: 0px; padding: 0px; visibility: visible; border-color: rgb(75, 116, 255); border-style: solid; mix-blend-mode: normal; backdrop-filter: none; border-width: 0px; border-radius: 0px; white-space: normal;"
  />
  <div
    data-v-53feabfc=""
    title=""
    class="main-content"
    theme="theme--light01"
    nctypography="custom"
    nucaldatamodel="[object Object]"
    id="95b277e1-334a-4c8f-beaf-f06b9b30c2f5"
    data-v-6cbd617a=""
    style="position: absolute; top: 1319px; left: 231px; color: rgb(0, 0, 0); width: 400px; filter: none; height: 90px; z-index: 13; font-style: normal; margin: 0px; text-align: left; background: transparent; font-family: Roboto; font-weight: 400; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-53feabfc="" style="background: transparent;">
      Take advantage of our flexible elements that allow you to drag and drop to
      build any type of form that you want.
    </span>
  </div>
  <div
    data-v-53feabfc=""
    title=""
    class="main-content"
    theme="theme--light01"
    nctypography="custom"
    nucaldatamodel="[object Object]"
    id="30cfdcd6-e7ef-4ee3-bee6-17575c64d4f3"
    data-v-6cbd617a=""
    style="position: absolute; top: 1887px; left: 231px; color: rgb(0, 0, 0); width: 400px; filter: none; height: 90px; z-index: 14; font-style: normal; margin: 0px; text-align: left; background: transparent; font-family: Roboto; font-weight: 400; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-53feabfc="" style="background: transparent;">
      Connect forms with the tools you already use (Slack, Zapier, Calendly,
      Klaviyo, HubSpot, Mailchimp, and over 6,000 more!) and get more value from
      your data.
    </span>
  </div>
  <div
    data-v-53feabfc=""
    title=""
    class="main-content"
    theme="theme--light01"
    nctypography="custom"
    nucaldatamodel="[object Object]"
    id="d5aab631-4ce7-4ffe-b7f6-0a630cd90b2e"
    data-v-6cbd617a=""
    style="position: absolute; top: 2454px; left: 232px; color: rgb(0, 0, 0); width: 400px; filter: none; height: 90px; z-index: 15; font-style: normal; margin: 0px; text-align: left; background: transparent; font-family: Roboto; font-weight: 400; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-53feabfc="" style="background: transparent;">
      Connect forms with the tools you already use (Slack, Zapier, Calendly,
      Klaviyo, HubSpot, Mailchimp, and over 6,000 more!) and get more value from
      your data.
    </span>
  </div>
  <h1
    data-v-fa233a80=""
    cite=""
    dir=""
    href=""
    title=""
    class="heading-content"
    theme="theme--light01"
    nctypography="custom"
    id="82b1fa53-dc0b-42cc-be4c-8b5bea8ef6a1"
    data-v-6cbd617a=""
    style="position: absolute; top: 2866px; left: 232px; color: rgb(0, 0, 0); width: 425px; filter: none; height: 114px; z-index: 16; font-style: normal; margin: 0px; text-align: left; background: transparent; font-family: Roboto; font-weight: 700; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-fa233a80="" style="background: transparent;">
      Boosting Completion Rates with Images
    </span>
  </h1>
  <img
    data-v-3f587a3a=""
    title="Please write a text to display in tooltip..."
    src="https://assets-global.website-files.com/65a921a3cf743bfaa970a60b/65ddea0d0815de19cdb08fa4_Boosting%20Completion%20Rates-p-1080.webp"
    class="image"
    dataloading="static"
    nucaldatamodel="[object Object]"
    datamodelfordynamictype="string"
    id="68e33ae4-c793-463d-8f95-a508d7878ed9"
    data-v-6cbd617a=""
    style="object-fit: fill; position: absolute; top: 2867px; left: 708px; width: 476px; filter: none; height: 233px; z-index: 17; margin: 0px; padding: 0px; visibility: visible; border-color: rgb(75, 116, 255); border-style: solid; mix-blend-mode: normal; backdrop-filter: none; border-width: 0px; border-radius: 0px; white-space: normal;"
  />
  <div
    data-v-53feabfc=""
    title=""
    class="main-content"
    theme="theme--light01"
    nctypography="custom"
    nucaldatamodel="[object Object]"
    id="b92712b5-4500-40f2-b2cd-4355cbd6327e"
    data-v-6cbd617a=""
    style="position: absolute; top: 3005px; left: 231px; color: rgb(0, 0, 0); width: 400px; filter: none; height: 90px; z-index: 18; font-style: normal; margin: 0px; text-align: left; background: transparent; font-family: Roboto; font-weight: 400; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-53feabfc="" style="background: transparent;">
      Connect forms with the tools you already use (Slack, Zapier, Calendly,
      Klaviyo, HubSpot, Mailchimp, and over 6,000 more!) and get more value from
      your data.
    </span>
  </div>
  <h1
    data-v-fa233a80=""
    cite=""
    dir=""
    href=""
    title=""
    class="heading-content"
    theme="theme--light01"
    nctypography="custom"
    id="53314c36-1d17-40f9-a20f-6d18e426718c"
    data-v-6cbd617a=""
    style="position: absolute; top: 3416px; left: 556px; color: rgb(4, 123, 242); width: 178px; filter: none; height: 50px; z-index: 19; font-style: normal; margin: 0px; text-align: center; background: transparent; font-family: Roboto; font-weight: 400; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-fa233a80="" style="background: transparent;">Features</span>
  </h1>
  <h1
    data-v-fa233a80=""
    cite=""
    dir=""
    href=""
    title=""
    class="heading-content"
    theme="theme--light01"
    nctypography="custom"
    id="d2b38fda-4953-4f8a-95d3-1b1a74705410"
    data-v-6cbd617a=""
    style="position: absolute; top: 3450px; left: 142px; color: rgb(0, 0, 0); width: 1017px; filter: none; height: 246px; z-index: 20; font-style: normal; margin: 0px; text-align: center; background: transparent; font-family: Roboto; font-weight: 700; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-fa233a80="" style="background: transparent;">
      Enhance your Forms experience
    </span>
  </h1>
  <img
    data-v-3f587a3a=""
    title="Please write a text to display in tooltip..."
    src="https://assets-global.website-files.com/65a921a3cf743bfaa970a60b/65d3d38d944bb9146db1063d_FormBot_Editor.svg"
    class="image"
    dataloading="static"
    nucaldatamodel="[object Object]"
    datamodelfordynamictype="string"
    id="93338336-304e-4801-921e-87b63f4f3f4b"
    data-v-6cbd617a=""
    style="object-fit: fill; position: absolute; top: 3698px; left: 282px; width: 752px; filter: none; height: 436px; z-index: 21; margin: 0px; padding: 0px; visibility: visible; border-color: rgb(75, 116, 255); border-style: solid; mix-blend-mode: normal; backdrop-filter: none; border-width: 0px; border-radius: 0px; white-space: normal;"
  />
  <div
    data-v-53feabfc=""
    title=""
    class="main-content"
    theme="theme--light01"
    nctypography="custom"
    nucaldatamodel="[object Object]"
    id="102343ac-e0bf-4c2a-87b9-e61466a658b8"
    data-v-6cbd617a=""
    style="position: absolute; top: 3548px; left: 365px; color: rgb(0, 0, 0); width: 562px; filter: none; height: 90px; z-index: 22; font-size: 16px; font-style: normal; margin: 0px; text-align: center; background: transparent; font-family: Roboto; font-weight: 400; line-height: 1.4; padding: 0px; text-indent: 0px; visibility: visible; white-space: normal; word-spacing: 0px; mix-blend-mode: normal; letter-spacing: 0px; text-transform: none; backdrop-filter: none; text-decoration: none;"
  >
    <span data-v-53feabfc="" style="background: transparent;">
      Discover FormBuilder's top features designed to streamline your digital
      workflow.
    </span>
  </div>
</div>
</template>

<script>
export default {
  name: 'Screen 1',
  data() {
    return {
      // Your data properties here
    };
  },
  props: {
    // Your component props here  
  },
  mounted() {
    // Code to run when the component is inserted into the DOM
  },
  methods: {
    // Your component methods here
  }
};
</script>

<style scoped>
  .nuc-container[data-v-6cbd617a] {
	background: rgb(255, 255, 255);
	user-select: none;
}

.heading-content[data-v-fa233a80] {
	text-overflow: inherit;
}

.btn {
	display: inline-block;
	font-weight: 400;
	color: rgb(33, 37, 41);
	text-align: center;
	vertical-align: middle;
	user-select: none;
	background-color: transparent;
	border: 1px solid transparent;
	padding: 0.375rem 0.75rem;
	font-size: 1rem;
	line-height: 1.5;
	border-radius: 0.25rem;
	transition: color 0.15s ease-in-out 0s, background-color 0.15s ease-in-out 0s, border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s, -webkit-box-shadow 0.15s ease-in-out 0s;
}

.btn-primary {
	color: rgb(255, 255, 255);
	background-color: rgb(0, 123, 255);
	border-color: rgb(0, 123, 255);
}

.main-content[data-v-53feabfc] {
	text-overflow: inherit;
}

.image[data-v-3f587a3a] {
	box-sizing: border-box;
	width: inherit;
	height: inherit;
}
</style>
